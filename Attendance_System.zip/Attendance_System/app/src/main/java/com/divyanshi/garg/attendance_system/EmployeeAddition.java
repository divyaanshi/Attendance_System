package com.divyanshi.garg.attendance_system;

public class EmployeeAddition {

    public String EmpID;
    public String Password;
    public String Name;

    public EmployeeAddition(){}


    public EmployeeAddition(String EmpID,String password,String Name){

        this.EmpID = EmpID;
        this.Password = password;
        this.Name = Name;
    }
}

